interface ImportMetaEnv {
  VITE_SCRIPT_ENCRYPTION_KEY: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
} 